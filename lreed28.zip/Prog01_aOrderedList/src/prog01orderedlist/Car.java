package prog01orderedlist;
/**
 * <This class implements the comparable interface Car >
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public class Car implements Comparable <Car> {

	private String make; //This variable is for the male of the car
	private int year;// This variable is for the year of the car
	private int price;//This variable is for the price of the car
	/**
	 * <This is a constructor for initializing the Cars objects >
	 * 
	 * Csc 1351 Programming Project No<1>
	 * 
	 * Section<2>
	 * 
	 * @author <Lexi Reed>
	 * @since <3/17/24>
	 * 
	 */

public Car(String Make, int Year, int Price) {
	this.make = Make;
	this.year = Year;
    this.price = Price;
}
/**
 * <this method gets the make of the car>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public String getMake() {
	return make;
}
/**
 * <this method gets the year of the car>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public int getYear() {
	return year;
}
/**
 * <this method gets the price of the car>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public int getPrice() {
	return price;
}
/**
 * <this method uses a compareto to comapare the cars objects >
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public int compareTo(Car other){
	if(this.make.compareTo(other.make) == 0) {
		return Integer.compare(this.year, other.year);
}	else {
		return this.make.compareTo(other.make);
}
}
/**
 * <this method returns the string of the cars objects>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */ 
public String toString() {
		return "Make: " + make + ", Year : " + year + ", Price: " + price + ";";
}
}
