package prog01orderedlist;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
/**
 * <This list contains the objects of the car and also has methods that can add and remove elements>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public class aOrderedList {
	final int SIZEINCREMENTS = 20;
	private Comparable[]oList;// This is an Array that stores the objects in the orderes list
	private int listSize;// This variable is for the total size of the list
	private int numObjects;// This variable shows the number of objects currently in the list
	private int curr;// This variable shows the current position in the list for iteration
	/**
	* <This method initializes the ordered list>
	*
	* CSC 1351 Programming Project No <enter project number here>
	* Section <insert your section number here>
	*
	* @author <Lexi Reed>
	* @since <3/17/24>
	*
	*/
public aOrderedList() {
	listSize = SIZEINCREMENTS;
	numObjects = 0;
	oList = new Comparable[SIZEINCREMENTS];
}
/**
* <This Method adds a new object to the ordered list>
*
* CSC 1351 Programming Project No <enter project number here>
* Section <insert your section number here>
*
* @author <insert your name here>
* @since <3/17/24>
*
*/
 void add(Comparable newCar) {
	if(numObjects == listSize) {
	listSize++;	
}
	int i;
	oList = Arrays.copyOf(oList, listSize);
	for (i = numObjects - 1; i >= 0 && oList[i].compareTo(newCar) > 0; i--) {
		oList[i+1] = oList[i];
}
	oList[i + 1] = newCar;
	numObjects++;
}
/**
* <This Method deletes the car from the list based on the make and year>
*
* CSC 1351 Programming Project No <enter project number here>
* Section <insert your section number here>
*
* @author <Lexi Reed>
* @since <3/17/24>
*
*/
public void delete (String make, int year) {
	for (int i = 0; i < numObjects; i++) {
		Car currcar = (Car) oList[i];
	if(currcar.getMake().equals(make) && currcar.getYear()== year) {
	for(int k = i; k <numObjects - 1; k++) {
				oList[k] = oList[k+1];
				}
			oList[numObjects -1 ] = null;
			numObjects--;
}
}
}
/**
 * <This method returns a string representaion of the ordered List>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public String toString() {
	String values = "[";
	for(int i=0; i< numObjects; i++) {
		values += oList[i].toString();
		if(i< numObjects - 1) {
			values += "[";
}
}
  values += "]";
  return values;
}
/**
 * <This Method returns the size of the ordered list>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public int size() {
	return numObjects;
}
/**
 * <This Method gets the element at the specified position in the list>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public Comparable get(int index) {
	return oList[index];
}
/**
 * <This Method checks if the list is empty>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public boolean isEmpty() {
	return numObjects == 0;

}
/**
 * <This Method removes the element at the specified position in the list>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public void remove(int index) {
if (index < 0 || index >= listSize)	{
	throw new IndexOutOfBoundsException(" The Index: " + index + " is out of bounds.");
}
for (int i = index; i < listSize - 1; i++) {
	oList[i] = oList[i+1];
}
numObjects--;
}
/**
 * <This Method resets the current position in the list>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public int reset() { 
	return curr = 0;
}
/**
 * <This Method gets the next element in the list during the iteration>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public Comparable next() {
 curr ++; 
 return oList[curr];
}
/**
 * <This Method checks if there's a next element during the iteration>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public boolean hasNext() {
 return (curr > numObjects);
 
}
/**
 * <This Method removes the current element during the iteration>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public void removecurr() {
	for(int i = curr; i < numObjects-1; i++) {
		oList[i]= oList[i+1];
}
	oList[curr]=null;
	numObjects--;
}

}


