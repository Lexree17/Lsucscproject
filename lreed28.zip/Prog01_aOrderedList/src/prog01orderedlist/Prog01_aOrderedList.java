package prog01orderedlist;
	import java.io.File;
	import java.io.FileNotFoundException;
	import java.io.PrintWriter;
	import java.util.Scanner;
	/**
	 * <This class Prompts the user for the input file and reads it. 
	 * It also gets the output file name from the user. >
	 * 
	 * Csc 1351 Programming Project No<1>
	 * 
	 * Section<2>
	 * 
	 * @author <Lexi Reed>
	 * @since <3/17/24>
	 * 
	 */
public class Prog01_aOrderedList {

public static void main(String[]args)throws FileNotFoundException{
	Scanner UserPrompt = new Scanner (System.in);
	// outFile = new PrintWriter("output.txt");
try {
	//ask for input file 
	Scanner in = GetInputFile("Enter File Name:");
	
	aOrderedList orderedList = new aOrderedList();
	
	//read input file
	while(in.hasNextLine()) {	
		String inputline = in.nextLine();
		String [] info = inputline.split(",");
	if(info.length == 4 &&  info[0].equals("A")) {
			String make = info[1];
			int year = Integer.parseInt(info[2]);
			int price =Integer.parseInt(info[3]);
		orderedList.add( new Car(make,year,price));
			
}   else if(info[0].equals("D")) {
			String myMake = info[1];
			int myYear = Integer.parseInt(info[2]);
	for(int i = 0; i < orderedList.size(); i++) {
	if(myMake.equals(((Car)orderedList.get(i)).getMake()) && myYear == (((Car)orderedList.get(i)).getYear())) {
					orderedList.remove(i);
}
}
}
}
	PrintWriter out = GetOutputFile("Enter Output File Name:");
    String orderedListString = ("Num of cars: \t\t" + orderedList.size() + "\n");
    
   int carIndex = 0;
    	// writes output car details to file
   while (carIndex < orderedList.size()) {
        orderedListString += String.format("\n\nMake:\t%s\nYear:\t%d\nPrice:\t$%,d", ((Car) orderedList.get(carIndex)).getMake(),
                ((Car) orderedList.get(carIndex)).getYear(), ((Car) orderedList.get(carIndex)).getPrice());
        carIndex++;
}
    	out.println(orderedListString);
    	out.close();
    	in.close();
} catch (FileNotFoundException e) {
    System.out.println(e.getMessage());
} 
}

/**
 * <This Method gets the input file>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException{
	boolean useriscorrect = false;
	Scanner scanFile = null;
	
	do {
			System.out.println(UserPrompt);
			Scanner scan = new Scanner(System.in);
			String input = scan.nextLine();
			
			File rightfile = new File(input);
	if(rightfile.exists()){
				scanFile = new Scanner(rightfile);
				useriscorrect = true;
}
			else {
				System.out.println("File specified does not exist. Would you like to continue? <Y/N>");
				String choose = scan.next();
				if (!choose.equalsIgnoreCase("Y")) {
					throw new FileNotFoundException("User is done");
}
}  
}	while(!useriscorrect);
	return scanFile;
}
/**
 * <This Method gets the output file>
 * 
 * Csc 1351 Programming Project No<1>
 * 
 * Section<2>
 * 
 * @author <Lexi Reed>
 * @since <3/17/24>
 * 
 */
public static PrintWriter GetOutputFile(String UserPrompt)throws FileNotFoundException{
	PrintWriter Writer = null;
	boolean validInput = false;
	Scanner scanner = new Scanner(System.in);
	
do {
	System.out.println(UserPrompt);
	String input = scanner.nextLine();
	File outputFile = new File(input);
	if(outputFile.exists()) {
		Writer = new PrintWriter(outputFile);
		validInput = true;
}
	else {
			System.out.println("File specified does not exist. Would you like to continue? <Y/N>");//
			String choose = scanner.nextLine();
			if(!choose.equalsIgnoreCase("Y")) {
				throw new FileNotFoundException("User is done");
}
}
}
	while(!validInput);
	
 return Writer;
}

}


 

